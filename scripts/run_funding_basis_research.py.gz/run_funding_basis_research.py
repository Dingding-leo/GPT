#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import math
import time
from collections.abc import Mapping, Sequence
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

import numpy as np
import pandas as pd

BASE_URL = "https://www.okx.com"
SOURCE_END = pd.Timestamp("2026-07-28T12:00:00Z")
FUNDING_START = pd.Timestamp("2026-04-28T00:00:00Z")
BASIS_START = FUNDING_START - pd.Timedelta(hours=48)
SPOT_START = pd.Timestamp("2026-01-20T00:00:00Z")
FEE = 0.0005
ANNUAL_HOURS = 8760.0
TREND_LOOKBACK = 2160
REFERENCE_EVENTS = 30
REFERENCE_HOURS = 240.0
MIN_EVALUATION_HOURS = 45 * 24
BLOCK_HOURS = 168
RESAMPLES = 5000
SEED = 20260728
ALLOWED_INTERVALS = {1, 2, 4, 6, 8}
MARKETS = {
    "BTC-USDT": {"swap": "BTC-USDT-SWAP", "index": "BTC-USDT"},
    "ETH-USDT": {"swap": "ETH-USDT-SWAP", "index": "ETH-USDT"},
}


def canonical_json(value: object) -> bytes:
    return (
        json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n"
    ).encode()


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def request_bytes(path: str, params: Mapping[str, str], timeout: float = 30.0) -> bytes:
    url = f"{BASE_URL}{path}?{urlencode(params)}"
    request = Request(
        url,
        headers={
            "Accept": "application/json",
            "User-Agent": "gpt-quant-lab/0.2 (+https://github.com/Dingding-leo/GPT)",
        },
    )
    last_error: Exception | None = None
    for attempt in range(4):
        try:
            with urlopen(request, timeout=timeout) as response:  # noqa: S310
                if response.status != 200:
                    raise RuntimeError(f"OKX HTTP status {response.status}")
                return response.read()
        except HTTPError as exc:
            last_error = exc
            if exc.code not in {408, 429, 500, 502, 503, 504} or attempt == 3:
                raise RuntimeError(f"OKX HTTP error {exc.code}") from exc
        except (URLError, TimeoutError) as exc:
            last_error = exc
            if attempt == 3:
                raise RuntimeError("OKX request failed after retries") from exc
        time.sleep(0.5 * (2**attempt))
    raise RuntimeError("OKX request failed") from last_error


def parse_payload(raw: bytes, *, label: str) -> Mapping[str, object]:
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"{label} response is not valid UTF-8 JSON") from exc
    if not isinstance(payload, Mapping):
        raise ValueError(f"{label} response must be a JSON object")
    if set(payload) != {"code", "msg", "data"}:
        raise ValueError(f"{label} response has unexpected top-level fields")
    if payload.get("code") != "0" or payload.get("msg") != "":
        raise ValueError(f"{label} request failed: {payload!r}")
    if not isinstance(payload.get("data"), list):
        raise ValueError(f"{label} data must be an array")
    return payload


def persist_pages(
    output_dir: Path,
    *,
    prefix: str,
    path: str,
    pages: list[tuple[dict[str, str], bytes]],
) -> dict[str, object]:
    manifest_pages: list[dict[str, object]] = []
    for index, (params, raw) in enumerate(pages, start=1):
        filename = f"{prefix}-page-{index:03d}.json"
        (output_dir / filename).write_bytes(raw)
        manifest_pages.append(
            {
                "file": filename,
                "params": dict(sorted(params.items())),
                "bytes": len(raw),
                "sha256": sha256_bytes(raw),
            }
        )
    return {"path": path, "pages": manifest_pages}


def fetch_object_pages(
    path: str,
    *,
    params: dict[str, str],
    time_field: str,
    start: pd.Timestamp,
    max_pages: int = 20,
) -> tuple[list[Mapping[str, object]], list[tuple[dict[str, str], bytes]]]:
    rows: list[Mapping[str, object]] = []
    pages: list[tuple[dict[str, str], bytes]] = []
    cursor: str | None = None
    seen_cursors: set[str] = set()
    for _ in range(max_pages):
        request_params = dict(params)
        if cursor is not None:
            request_params["after"] = cursor
        raw = request_bytes(path, request_params)
        pages.append((request_params, raw))
        payload = parse_payload(raw, label=path)
        data = payload["data"]
        assert isinstance(data, list)
        if not data:
            break
        page_times: list[int] = []
        for row in data:
            if not isinstance(row, Mapping):
                raise ValueError(f"{path} contains a non-object row")
            value = row.get(time_field)
            if not isinstance(value, str) or not value.isascii() or not value.isdecimal():
                raise ValueError(f"{path} contains invalid {time_field}")
            page_times.append(int(value))
            rows.append(row)
        oldest = min(page_times)
        if pd.to_datetime(oldest, unit="ms", utc=True) <= start:
            break
        next_cursor = str(oldest)
        if next_cursor in seen_cursors:
            raise ValueError(f"{path} repeated pagination cursor")
        seen_cursors.add(next_cursor)
        cursor = next_cursor
        time.sleep(0.12)
    else:
        raise ValueError(f"{path} exceeded page budget")
    return rows, pages


def fetch_candle_pages(
    path: str,
    *,
    inst_id: str,
    start: pd.Timestamp,
    end: pd.Timestamp,
    max_pages: int,
) -> tuple[pd.DataFrame, list[tuple[dict[str, str], bytes]]]:
    rows: list[list[object]] = []
    pages: list[tuple[dict[str, str], bytes]] = []
    cursor: str | None = None
    seen_cursors: set[str] = set()
    for _ in range(max_pages):
        params = {"instId": inst_id, "bar": "1H", "limit": "100"}
        if cursor is not None:
            params["after"] = cursor
        raw = request_bytes(path, params)
        pages.append((params, raw))
        payload = parse_payload(raw, label=f"{path}:{inst_id}")
        data = payload["data"]
        assert isinstance(data, list)
        if not data:
            break
        page_times: list[int] = []
        for row in data:
            if not isinstance(row, Sequence) or isinstance(row, (str, bytes)):
                raise ValueError(f"{path}:{inst_id} contains a non-array row")
            if len(row) not in {6, 9}:
                raise ValueError(f"{path}:{inst_id} row must have 6 or 9 fields")
            timestamp = row[0]
            if not isinstance(timestamp, str) or not timestamp.isascii() or not timestamp.isdecimal():
                raise ValueError(f"{path}:{inst_id} contains invalid timestamp")
            page_times.append(int(timestamp))
            rows.append(list(row))
        oldest = min(page_times)
        if pd.to_datetime(oldest, unit="ms", utc=True) <= start:
            break
        next_cursor = str(oldest)
        if next_cursor in seen_cursors:
            raise ValueError(f"{path}:{inst_id} repeated pagination cursor")
        seen_cursors.add(next_cursor)
        cursor = next_cursor
        time.sleep(0.12)
    else:
        raise ValueError(f"{path}:{inst_id} exceeded page budget")

    normalized: dict[pd.Timestamp, tuple[float, float, float, float, str, tuple[object, ...]]] = {}
    for row in rows:
        timestamp = pd.to_datetime(int(str(row[0])), unit="ms", utc=True)
        if timestamp.floor("h") != timestamp:
            raise ValueError(f"{path}:{inst_id} timestamp is not UTC-hour aligned")
        try:
            open_price, high, low, close = (float(row[i]) for i in range(1, 5))
        except (TypeError, ValueError, OverflowError) as exc:
            raise ValueError(f"{path}:{inst_id} has invalid OHLC") from exc
        confirm = str(row[5] if len(row) == 6 else row[8])
        values = np.asarray([open_price, high, low, close])
        if not np.isfinite(values).all() or bool((values <= 0).any()):
            raise ValueError(f"{path}:{inst_id} has non-positive/non-finite OHLC")
        if high < max(open_price, close, low) or low > min(open_price, close, high):
            raise ValueError(f"{path}:{inst_id} violates OHLC invariants")
        if confirm != "1":
            continue
        canonical = (open_price, high, low, close, confirm, tuple(row))
        previous = normalized.get(timestamp)
        if previous is not None and previous != canonical:
            raise ValueError(f"{path}:{inst_id} contains conflicting duplicate candle")
        normalized[timestamp] = canonical

    selected = [
        (timestamp, *values[:5])
        for timestamp, values in normalized.items()
        if start <= timestamp < end
    ]
    frame = pd.DataFrame(
        selected,
        columns=["timestamp", "open", "high", "low", "close", "confirm"],
    ).sort_values("timestamp")
    if frame.empty:
        raise ValueError(f"{path}:{inst_id} produced no selected candles")
    frame = frame.set_index("timestamp")
    expected = pd.date_range(start.ceil("h"), end - pd.Timedelta(hours=1), freq="1h")
    if not frame.index.equals(expected):
        missing = expected.difference(frame.index)
        extra = frame.index.difference(expected)
        raise ValueError(
            f"{path}:{inst_id} candle grid mismatch rows={len(frame)} "
            f"missing={len(missing)} extra={len(extra)}"
        )
    return frame, pages


def parse_funding(rows: list[Mapping[str, object]], *, swap: str) -> pd.DataFrame:
    normalized: dict[pd.Timestamp, tuple[object, ...]] = {}
    for row in rows:
        required = {
            "instType",
            "instId",
            "fundingRate",
            "realizedRate",
            "fundingTime",
            "formulaType",
            "method",
        }
        if not required.issubset(row):
            raise ValueError(f"{swap} funding row missing required fields: {required - set(row)}")
        if row["instId"] != swap or row["instType"] != "SWAP":
            raise ValueError(f"{swap} funding row instrument mismatch")
        timestamp_raw = row["fundingTime"]
        if not isinstance(timestamp_raw, str) or not timestamp_raw.isascii() or not timestamp_raw.isdecimal():
            raise ValueError(f"{swap} funding row has invalid fundingTime")
        timestamp = pd.to_datetime(int(timestamp_raw), unit="ms", utc=True)
        if timestamp.floor("h") != timestamp:
            raise ValueError(f"{swap} funding settlement is not UTC-hour aligned")
        try:
            funding_rate = float(row["fundingRate"])
            realized_rate = float(row["realizedRate"])
        except (TypeError, ValueError, OverflowError) as exc:
            raise ValueError(f"{swap} funding row has invalid rate") from exc
        if not np.isfinite([funding_rate, realized_rate]).all():
            raise ValueError(f"{swap} funding row has non-finite rate")
        formula = row["formulaType"]
        method = row["method"]
        if not isinstance(formula, str) or not isinstance(method, str):
            raise ValueError(f"{swap} funding row has invalid regime fields")
        canonical = (
            funding_rate,
            realized_rate,
            formula,
            method,
            json.dumps(dict(row), sort_keys=True, separators=(",", ":")),
        )
        previous = normalized.get(timestamp)
        if previous is not None and previous != canonical:
            raise ValueError(f"{swap} contains conflicting funding duplicate")
        normalized[timestamp] = canonical

    selected = [
        (timestamp, values[0], values[1], values[2], values[3])
        for timestamp, values in normalized.items()
        if FUNDING_START <= timestamp < SOURCE_END
    ]
    frame = pd.DataFrame(
        selected,
        columns=["funding_time", "funding_rate", "realized_rate", "formula_type", "method"],
    ).sort_values("funding_time")
    if frame.empty:
        raise ValueError(f"{swap} funding history is empty")
    frame = frame.set_index("funding_time")
    if frame.index.has_duplicates or not frame.index.is_monotonic_increasing:
        raise ValueError(f"{swap} normalized funding timestamps are invalid")
    return frame


def weighted_median(values: np.ndarray, weights: np.ndarray, times: np.ndarray) -> float:
    order = np.lexsort((times, values))
    ordered_values = values[order]
    ordered_weights = weights[order]
    threshold = float(np.sum(ordered_weights)) / 2.0
    cumulative = np.cumsum(ordered_weights)
    return float(ordered_values[int(np.searchsorted(cumulative, threshold, side="left"))])


def weighted_mad(
    values: np.ndarray,
    weights: np.ndarray,
    times: np.ndarray,
    center: float,
) -> float:
    deviations = np.abs(values - center)
    return weighted_median(deviations, weights, times)


def build_event_features(
    funding: pd.DataFrame,
    mark: pd.DataFrame,
    index: pd.DataFrame,
) -> tuple[pd.DataFrame, dict[str, int]]:
    frame = funding.copy()
    basis = np.log(mark["close"] / index["close"])
    features: list[dict[str, object]] = []
    previous_time: pd.Timestamp | None = None
    previous_regime: tuple[str, str] | None = None
    episode_id = -1
    episode_history: list[dict[str, object]] = []
    counts = {
        "events": 0,
        "invalid_interval": 0,
        "regime_transitions": 0,
        "missing_basis": 0,
        "missing_recovery": 0,
        "incomplete_warmup": 0,
        "zero_mad": 0,
        "valid_f0_events": 0,
        "valid_f1_events": 0,
    }

    for timestamp, row in frame.iterrows():
        counts["events"] += 1
        formula = str(row.formula_type)
        method = str(row.method)
        regime = (formula, method)
        if previous_regime is None or regime != previous_regime or not formula or not method:
            episode_id += 1
            episode_history = []
            if previous_regime is not None:
                counts["regime_transitions"] += 1
        previous_regime = regime

        interval: int | None = None
        if previous_time is not None:
            delta_hours = (timestamp - previous_time).total_seconds() / 3600.0
            if delta_hours.is_integer() and int(delta_hours) in ALLOWED_INTERVALS:
                interval = int(delta_hours)
        previous_time = timestamp
        valid_interval = interval is not None
        if not valid_interval:
            counts["invalid_interval"] += 1

        candle_open = timestamp - pd.Timedelta(hours=1)
        basis_value = float("nan")
        recovery = float("nan")
        if candle_open in basis.index:
            basis_value = float(basis.loc[candle_open])
        else:
            counts["missing_basis"] += 1
        recovery_open = candle_open - pd.Timedelta(hours=24)
        if candle_open in basis.index and recovery_open in basis.index:
            recovery = float(basis.loc[candle_open] - basis.loc[recovery_open])
        else:
            counts["missing_recovery"] += 1

        funding_8h = (
            float(row.realized_rate) * 8.0 / interval if interval is not None else float("nan")
        )
        z_funding = z_basis = z_recovery = float("nan")
        enough = (
            len(episode_history) >= REFERENCE_EVENTS
            and sum(float(item["interval"]) for item in episode_history) >= REFERENCE_HOURS
        )
        if enough and valid_interval and np.isfinite([basis_value, recovery, funding_8h]).all():
            weights = np.asarray([float(item["interval"]) for item in episode_history])
            times = np.asarray([int(item["timestamp_ms"]) for item in episode_history])
            z_values: list[float] = []
            zero_scale = False
            for key, current in (
                ("funding_8h", funding_8h),
                ("basis", basis_value),
                ("recovery", recovery),
            ):
                history_values = np.asarray([float(item[key]) for item in episode_history])
                center = weighted_median(history_values, weights, times)
                scale = weighted_mad(history_values, weights, times, center)
                if not np.isfinite(scale) or scale <= 0:
                    zero_scale = True
                    break
                z_values.append(float(np.clip((current - center) / scale, -6.0, 6.0)))
            if zero_scale:
                counts["zero_mad"] += 1
            else:
                z_funding, z_basis, z_recovery = z_values
        else:
            counts["incomplete_warmup"] += 1

        f0_target = 0.0
        f1_target = 0.0
        feature_valid = np.isfinite([z_funding, z_basis, z_recovery]).all()
        if feature_valid and funding_8h < 0:
            f0_target = max(0.0, math.tanh(-z_funding))
            if f0_target > 0:
                counts["valid_f0_events"] += 1
        if feature_valid and funding_8h < 0 and basis_value < 0 and recovery > 0:
            f1_target = max(0.0, math.tanh(min(-z_funding, -z_basis, z_recovery)))
            if f1_target > 0:
                counts["valid_f1_events"] += 1

        valid_history_row = (
            valid_interval
            and np.isfinite([funding_8h, basis_value, recovery]).all()
            and bool(formula)
            and bool(method)
        )
        if valid_history_row:
            episode_history.append(
                {
                    "interval": float(interval),
                    "timestamp_ms": int(timestamp.timestamp() * 1000),
                    "funding_8h": funding_8h,
                    "basis": basis_value,
                    "recovery": recovery,
                }
            )

        features.append(
            {
                "funding_time": timestamp,
                "episode_id": episode_id,
                "formula_type": formula,
                "method": method,
                "interval_hours": interval,
                "funding_8h": funding_8h,
                "basis": basis_value,
                "recovery": recovery,
                "z_funding": z_funding,
                "z_basis": z_basis,
                "z_recovery": z_recovery,
                "feature_valid": bool(feature_valid),
                "f0_target": f0_target,
                "f1_target": f1_target,
                "activation": timestamp + pd.Timedelta(hours=1),
                "matched_candle_open": candle_open,
            }
        )
    return pd.DataFrame(features).set_index("funding_time"), counts


def build_hourly_targets(events: pd.DataFrame, hourly_index: pd.DatetimeIndex) -> pd.DataFrame:
    decisions: dict[pd.Timestamp, tuple[int, float, float, int | None, str]] = {}
    expiry_count = 0
    for _, event in events.iterrows():
        activation = pd.Timestamp(event.activation)
        episode = int(event.episode_id)
        decisions[activation] = (
            2,
            float(event.f0_target),
            float(event.f1_target),
            episode,
            "event",
        )
        interval = event.interval_hours
        if interval is not None and np.isfinite(float(interval)):
            expiry = activation + pd.Timedelta(hours=int(interval))
            previous = decisions.get(expiry)
            if previous is None or previous[0] < 1:
                decisions[expiry] = (1, 0.0, 0.0, episode, "expiry")
                expiry_count += 1

    f0 = 0.0
    f1 = 0.0
    episode: int | None = None
    rows: list[tuple[pd.Timestamp, float, float, int | None, str]] = []
    for timestamp in hourly_index:
        reason = "carry"
        decision = decisions.get(timestamp)
        if decision is not None:
            _, f0, f1, episode, reason = decision
        rows.append((timestamp, f0, f1, episode, reason))
    frame = pd.DataFrame(
        rows,
        columns=["timestamp", "f0_target", "f1_target", "episode_id", "decision_reason"],
    ).set_index("timestamp")
    frame.attrs["expiry_decisions"] = expiry_count
    return frame


def validate_spot(frame: pd.DataFrame) -> None:
    if frame.index.has_duplicates or not frame.index.is_monotonic_increasing:
        raise ValueError("spot candle timestamps must be unique and increasing")
    if not bool((frame.index[1:] - frame.index[:-1] == pd.Timedelta(hours=1)).all()):
        raise ValueError("spot candles must be contiguous 1H")
    if not bool((frame.confirm.astype(str) == "1").all()):
        raise ValueError("spot candles must all be confirmed")


def trend_target(spot: pd.DataFrame) -> pd.Series:
    prior_close = spot.close.shift(1)
    old_close = spot.close.shift(TREND_LOOKBACK + 1)
    return (prior_close / old_close - 1.0 > 0).astype(float)


def strategy_path(target: pd.Series, spot: pd.DataFrame, evaluation: pd.DatetimeIndex) -> pd.DataFrame:
    position = target.reindex(evaluation).astype(float)
    market_return = spot.open.shift(-1).reindex(evaluation) / spot.open.reindex(evaluation) - 1.0
    if not np.isfinite(position).all() or not np.isfinite(market_return).all():
        raise ValueError("strategy evaluation contains unavailable values")
    values = position.to_numpy(float)
    previous = np.r_[0.0, values[:-1]]
    turnover = np.abs(values - previous)
    gross = values * market_return.to_numpy(float)
    fee = FEE * turnover
    return pd.DataFrame(
        {
            "position": values,
            "market_return": market_return.to_numpy(float),
            "gross_return": gross,
            "turnover": turnover,
            "fee": fee,
            "net_return": gross - fee,
        },
        index=evaluation,
    )


def sharpe(values: np.ndarray) -> float:
    scale = float(np.std(values, ddof=1))
    if not np.isfinite(scale) or scale <= 0:
        return 0.0
    return float(np.mean(values) / scale * math.sqrt(ANNUAL_HOURS))


def max_drawdown(values: np.ndarray) -> float:
    wealth = np.cumprod(1.0 + values)
    return float(np.min(wealth / np.maximum.accumulate(wealth) - 1.0))


def edge_per_turnover(values: np.ndarray, turnover: np.ndarray) -> float | None:
    years = len(values) / ANNUAL_HOURS
    annual_turnover = float(np.sum(turnover) / years)
    if annual_turnover <= 0:
        return None
    return float(np.mean(values) * ANNUAL_HOURS / annual_turnover * 1e4)


def holding_durations(position: np.ndarray) -> list[int]:
    durations: list[int] = []
    current = 0
    for value in position:
        if value > 1e-15:
            current += 1
        elif current:
            durations.append(current)
            current = 0
    if current:
        durations.append(current)
    return durations


def path_metrics(path: pd.DataFrame) -> dict[str, object]:
    net = path.net_return.to_numpy(float)
    gross = path.gross_return.to_numpy(float)
    turnover = path.turnover.to_numpy(float)
    position = path.position.to_numpy(float)
    total_return = float(np.prod(1.0 + net) - 1.0)
    drawdown = max_drawdown(net)
    annualized_compound = float((1.0 + total_return) ** (ANNUAL_HOURS / len(net)) - 1.0)
    blocks = [
        float(np.prod(1.0 + net[start : start + BLOCK_HOURS]) - 1.0)
        for start in range(0, len(net) - BLOCK_HOURS + 1, BLOCK_HOURS)
    ]
    positive = [value for value in blocks if value > 0]
    concentration = max(positive) / sum(positive) if positive else None
    rolling_24 = pd.Series(net).rolling(24).apply(lambda x: np.prod(1.0 + x) - 1.0)
    rolling_168 = pd.Series(net).rolling(168).apply(lambda x: np.prod(1.0 + x) - 1.0)
    downside = np.minimum(net, 0.0)
    durations = holding_durations(position)
    return {
        "observations": len(net),
        "gross_return": float(np.prod(1.0 + gross) - 1.0),
        "net_return": total_return,
        "annualized_arithmetic_mean": float(np.mean(net) * ANNUAL_HOURS),
        "annualized_compound_return": annualized_compound,
        "annualized_sharpe": sharpe(net),
        "calmar": annualized_compound / abs(drawdown) if drawdown < 0 else None,
        "max_drawdown": drawdown,
        "downside_semivolatility": float(np.sqrt(np.mean(downside**2)) * math.sqrt(ANNUAL_HOURS)),
        "absolute_turnover": float(np.sum(turnover)),
        "annualized_turnover": float(np.sum(turnover) / (len(net) / ANNUAL_HOURS)),
        "modeled_fee_sum": float(np.sum(path.fee)),
        "edge_per_turnover_bps": edge_per_turnover(net, turnover),
        "adjustment_count": int(np.count_nonzero(turnover > 1e-15)),
        "time_in_market": float(np.mean(position > 1e-15)),
        "mean_exposure": float(np.mean(position)),
        "median_holding_hours": float(np.median(durations)) if durations else None,
        "complete_168h_blocks": len(blocks),
        "profitable_168h_blocks": int(sum(value > 0 for value in blocks)),
        "positive_block_concentration": concentration,
        "worst_24h_return": float(rolling_24.min()),
        "worst_168h_return": float(rolling_168.min()),
    }


def residual_metrics(candidate: pd.DataFrame, benchmark: pd.DataFrame) -> dict[str, float]:
    difference = candidate.net_return.to_numpy(float) - benchmark.net_return.to_numpy(float)
    return {
        "annualized_mean": float(np.mean(difference) * ANNUAL_HOURS),
        "sharpe": sharpe(difference),
        "compounded_difference": float(
            np.prod(1.0 + candidate.net_return.to_numpy(float))
            - np.prod(1.0 + benchmark.net_return.to_numpy(float))
        ),
    }


def episode_segments(episodes: pd.Series) -> list[np.ndarray]:
    values = episodes.to_numpy()
    segments: list[np.ndarray] = []
    start = 0
    for index in range(1, len(values) + 1):
        if index == len(values) or values[index] != values[start]:
            segment = np.arange(start, index)
            if len(segment) >= BLOCK_HOURS:
                segments.append(segment)
            start = index
    return segments


def sample_indices(segments: list[np.ndarray], length: int, rng: np.random.Generator) -> np.ndarray:
    choices: list[np.ndarray] = []
    total = 0
    while total < length:
        segment = segments[int(rng.integers(0, len(segments)))]
        start = int(rng.integers(0, len(segment) - BLOCK_HOURS + 1))
        block = segment[start : start + BLOCK_HOURS]
        choices.append(block)
        total += len(block)
    return np.concatenate(choices)[:length]


def holm_adjust(raw: dict[str, float]) -> dict[str, float]:
    ordered = sorted(raw.items(), key=lambda item: item[1])
    adjusted: dict[str, float] = {}
    running = 0.0
    for index, (name, value) in enumerate(ordered):
        running = max(running, min(1.0, (len(ordered) - index) * value))
        adjusted[name] = running
    return adjusted


def bootstrap(
    paths: dict[str, dict[str, pd.DataFrame]],
    episodes: dict[str, pd.Series],
) -> dict[str, object]:
    observed_market: dict[str, dict[str, float | None]] = {}
    for market, policy in paths.items():
        f0 = policy["f0"]
        f1 = policy["f1"]
        f0_edge = edge_per_turnover(f0.net_return.to_numpy(), f0.turnover.to_numpy())
        f1_edge = edge_per_turnover(f1.net_return.to_numpy(), f1.turnover.to_numpy())
        observed_market[market] = {
            "sharpe": sharpe(f1.net_return.to_numpy()) - sharpe(f0.net_return.to_numpy()),
            "edge": None if f0_edge is None or f1_edge is None else f1_edge - f0_edge,
        }
    observed = {
        "worst_market_sharpe": min(float(value["sharpe"]) for value in observed_market.values()),
        "worst_market_edge": (
            None
            if any(value["edge"] is None for value in observed_market.values())
            else min(float(value["edge"]) for value in observed_market.values())
        ),
    }

    rng = np.random.default_rng(SEED)
    samples = {name: [] for name in observed}
    segments = {market: episode_segments(series) for market, series in episodes.items()}
    if any(not value for value in segments.values()):
        return {
            "block_hours": BLOCK_HOURS,
            "resamples": 0,
            "seed": SEED,
            "observed": observed,
            "endpoints": {
                name: {"one_sided_95pct_lower_bound": None, "holm_adjusted_p": None}
                for name in observed
            },
            "reason": "no_contiguous_episode_supports_one_168h_block",
        }

    for _ in range(RESAMPLES):
        market_stats: dict[str, list[float]] = {name: [] for name in observed}
        for market, policy in paths.items():
            indices = sample_indices(segments[market], len(policy["f0"]), rng)
            f0 = policy["f0"].iloc[indices]
            f1 = policy["f1"].iloc[indices]
            market_stats["worst_market_sharpe"].append(
                sharpe(f1.net_return.to_numpy()) - sharpe(f0.net_return.to_numpy())
            )
            f0_edge = edge_per_turnover(f0.net_return.to_numpy(), f0.turnover.to_numpy())
            f1_edge = edge_per_turnover(f1.net_return.to_numpy(), f1.turnover.to_numpy())
            if f0_edge is not None and f1_edge is not None:
                market_stats["worst_market_edge"].append(f1_edge - f0_edge)
        for name, values in market_stats.items():
            if len(values) == len(paths):
                samples[name].append(float(min(values)))

    raw_p: dict[str, float] = {}
    endpoints: dict[str, object] = {}
    for name, values in samples.items():
        theta = observed[name]
        if theta is None or len(values) != RESAMPLES:
            endpoints[name] = {
                "valid_resamples": len(values),
                "one_sided_95pct_lower_bound": None,
                "raw_p": None,
            }
            continue
        array = np.asarray(values, dtype=float)
        errors = array - float(theta)
        lower = float(theta) - float(np.quantile(errors, 0.95))
        raw = float((1 + np.count_nonzero(errors >= float(theta))) / (RESAMPLES + 1))
        raw_p[name] = raw
        endpoints[name] = {
            "valid_resamples": len(array),
            "one_sided_95pct_lower_bound": lower,
            "raw_p": raw,
            "basic_90pct_interval": [
                float(2 * float(theta) - np.quantile(array, 0.95)),
                float(2 * float(theta) - np.quantile(array, 0.05)),
            ],
        }
    for name, value in holm_adjust(raw_p).items():
        endpoints[name]["holm_adjusted_p"] = value
    return {
        "block_hours": BLOCK_HOURS,
        "resamples": RESAMPLES,
        "seed": SEED,
        "observed": observed,
        "endpoints": endpoints,
    }


def run_causal_attacks(
    funding: pd.DataFrame,
    mark: pd.DataFrame,
    index: pd.DataFrame,
    events: pd.DataFrame,
    spot: pd.DataFrame,
) -> dict[str, bool]:
    if not bool((events.matched_candle_open == events.index - pd.Timedelta(hours=1)).all()):
        raise ValueError("event basis used a non-causal candle")
    cutoff = events.index[len(events) // 2]
    mutated_funding = funding.copy()
    suffix = mutated_funding.index > cutoff
    mutated_funding.loc[suffix, "realized_rate"] *= -1.31
    mutated_events, _ = build_event_features(mutated_funding, mark, index)
    prefix = events.index <= cutoff
    funding_invariant = bool(
        np.allclose(
            events.loc[prefix, ["f0_target", "f1_target"]],
            mutated_events.loc[prefix, ["f0_target", "f1_target"]],
            atol=0.0,
            rtol=0.0,
            equal_nan=True,
        )
    )
    mutated_mark = mark.copy()
    mark_suffix = mutated_mark.index > cutoff
    mutated_mark.loc[mark_suffix, "close"] *= 1.013
    mutated_basis_events, _ = build_event_features(funding, mutated_mark, index)
    basis_invariant = bool(
        np.allclose(
            events.loc[prefix, ["f0_target", "f1_target"]],
            mutated_basis_events.loc[prefix, ["f0_target", "f1_target"]],
            atol=0.0,
            rtol=0.0,
            equal_nan=True,
        )
    )
    gap_rejected = False
    gapped = spot.drop(spot.index[len(spot) // 2])
    try:
        validate_spot(gapped)
    except ValueError:
        gap_rejected = True
    positive_funding_cash = bool(
        (events.loc[events.funding_8h >= 0, "f0_target"] == 0).all()
    )
    conjunction_cash = bool(
        (
            events.loc[
                (events.funding_8h >= 0) | (events.basis >= 0) | (events.recovery <= 0),
                "f1_target",
            ]
            == 0
        ).all()
    )
    return {
        "basis_uses_t_minus_1h_candle": True,
        "future_funding_suffix_invariance": funding_invariant,
        "future_basis_suffix_invariance": basis_invariant,
        "gapped_spot_rejected": gap_rejected,
        "positive_funding_forces_f0_cash": positive_funding_cash,
        "strict_conjunction_forces_f1_cash": conjunction_cash,
    }


def capacity(metrics: Mapping[str, object]) -> dict[str, object]:
    annual_turnover = float(metrics["annualized_turnover"])
    absolute_turnover = float(metrics["absolute_turnover"])
    observations = int(metrics["observations"])
    max_hour_fraction = absolute_turnover / observations if observations else 0.0
    notionals = [10_000, 100_000, 1_000_000]
    result = {}
    for notional in notionals:
        result[str(notional)] = {
            "annual_adjusted_notional": annual_turnover * notional,
            "modeled_annual_fee": annual_turnover * notional * FEE,
            "mean_hour_adjustment_proxy": max_hour_fraction * notional,
        }
    result["10x_10000"] = {
        "annual_adjusted_notional": annual_turnover * 100_000,
        "modeled_annual_fee": annual_turnover * 100_000 * FEE,
        "note": "diagnostic scaling only; leverage is not used or authorized",
    }
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    source_manifests: dict[str, object] = {}
    market_inputs: dict[str, dict[str, object]] = {}
    readiness: list[pd.Timestamp] = []

    for spot_id, binding in MARKETS.items():
        swap = binding["swap"]
        index_id = binding["index"]
        funding_rows, funding_pages = fetch_object_pages(
            "/api/v5/public/funding-rate-history",
            params={"instId": swap, "limit": "100"},
            time_field="fundingTime",
            start=FUNDING_START,
            max_pages=12,
        )
        funding = parse_funding(funding_rows, swap=swap)
        mark, mark_pages = fetch_candle_pages(
            "/api/v5/market/history-mark-price-candles",
            inst_id=swap,
            start=BASIS_START,
            end=SOURCE_END,
            max_pages=30,
        )
        index, index_pages = fetch_candle_pages(
            "/api/v5/market/history-index-candles",
            inst_id=index_id,
            start=BASIS_START,
            end=SOURCE_END,
            max_pages=30,
        )
        spot, spot_pages = fetch_candle_pages(
            "/api/v5/market/history-candles",
            inst_id=spot_id,
            start=SPOT_START,
            end=SOURCE_END,
            max_pages=55,
        )
        validate_spot(spot)
        events, event_counts = build_event_features(funding, mark, index)
        valid_activations = events.loc[events.feature_valid, "activation"]
        if valid_activations.empty:
            ready = SOURCE_END
        else:
            ready = pd.Timestamp(valid_activations.iloc[0])
        readiness.append(ready)
        market_inputs[spot_id] = {
            "funding": funding,
            "mark": mark,
            "index": index,
            "spot": spot,
            "events": events,
            "event_counts": event_counts,
        }
        source_manifests[spot_id] = {
            "funding": persist_pages(
                args.output_dir,
                prefix=f"{spot_id}-funding",
                path="/api/v5/public/funding-rate-history",
                pages=funding_pages,
            ),
            "mark": persist_pages(
                args.output_dir,
                prefix=f"{spot_id}-mark",
                path="/api/v5/market/history-mark-price-candles",
                pages=mark_pages,
            ),
            "index": persist_pages(
                args.output_dir,
                prefix=f"{spot_id}-index",
                path="/api/v5/market/history-index-candles",
                pages=index_pages,
            ),
            "spot": persist_pages(
                args.output_dir,
                prefix=f"{spot_id}-spot",
                path="/api/v5/market/history-candles",
                pages=spot_pages,
            ),
        }

    evaluation_start = max(readiness).ceil("h")
    evaluation_end = SOURCE_END - pd.Timedelta(hours=1)
    expected = pd.date_range(evaluation_start, evaluation_end, freq="1h")
    result: dict[str, object] = {
        "family_id": "funding-basis-crowding-unwind-v2",
        "issue": 541,
        "source_head_sha": "fda3c8cc5fe8c1902ce7fbaf3fe51edd5c337791",
        "candidate_count": 2,
        "fee_one_way_bps": 5.0,
        "classification": "shorter_window_recent_public_history_diagnostic",
        "fixed_boundaries": {
            "funding_start": FUNDING_START.isoformat(),
            "basis_start": BASIS_START.isoformat(),
            "spot_start": SPOT_START.isoformat(),
            "source_end_exclusive": SOURCE_END.isoformat(),
        },
        "evaluation": {
            "start": evaluation_start.isoformat(),
            "end_inclusive": evaluation_end.isoformat(),
            "hours": len(expected),
            "minimum_hours": MIN_EVALUATION_HOURS,
        },
        "source_manifests": source_manifests,
        "markets": {},
        "dsr": None,
        "pbo": None,
        "untouched_archive_consumed": False,
    }

    if len(expected) < MIN_EVALUATION_HOURS:
        result["verdict"] = "insufficient_source_coverage"
        result["reason"] = "fewer_than_45_complete_evaluation_days_after_causal_warmup"
    else:
        paths: dict[str, dict[str, pd.DataFrame]] = {}
        hourly_episodes: dict[str, pd.Series] = {}
        deterministic_payloads: dict[str, bytes] = {}
        for spot_id, inputs in market_inputs.items():
            funding = inputs["funding"]
            mark = inputs["mark"]
            index = inputs["index"]
            spot = inputs["spot"]
            events = inputs["events"]
            event_counts = inputs["event_counts"]
            assert isinstance(funding, pd.DataFrame)
            assert isinstance(mark, pd.DataFrame)
            assert isinstance(index, pd.DataFrame)
            assert isinstance(spot, pd.DataFrame)
            assert isinstance(events, pd.DataFrame)
            hourly = build_hourly_targets(events, spot.index)
            f0 = strategy_path(hourly.f0_target, spot, expected)
            f1 = strategy_path(hourly.f1_target, spot, expected)
            trend = strategy_path(trend_target(spot), spot, expected)
            paths[spot_id] = {"f0": f0, "f1": f1, "trend": trend}
            episodes = hourly.episode_id.reindex(expected).ffill().fillna(-1).astype(int)
            hourly_episodes[spot_id] = episodes
            attacks = run_causal_attacks(funding, mark, index, events, spot)
            if not all(attacks.values()):
                raise ValueError(f"{spot_id} causal attack failed: {attacks}")
            f0_metrics = path_metrics(f0)
            f1_metrics = path_metrics(f1)
            trend_metrics = path_metrics(trend)
            market_result = {
                "funding_rows": len(funding),
                "funding_first": funding.index[0].isoformat(),
                "funding_last": funding.index[-1].isoformat(),
                "formula_method_episodes": int(events.episode_id.max() + 1),
                "event_counts": event_counts,
                "expiry_decisions": int(hourly.attrs["expiry_decisions"]),
                "hours_forced_cash_f0": int(np.count_nonzero(hourly.f0_target.reindex(expected) == 0)),
                "hours_forced_cash_f1": int(np.count_nonzero(hourly.f1_target.reindex(expected) == 0)),
                "causal_attacks": attacks,
                "policies": {
                    "f0_funding_only": f0_metrics,
                    "f1_strict_unwind": f1_metrics,
                    "simple_trend_2160h_next_open": trend_metrics,
                },
                "benchmark_residual": {
                    "f0_minus_trend": residual_metrics(f0, trend),
                    "f1_minus_trend": residual_metrics(f1, trend),
                },
                "f1_minus_f0": {
                    "net_return_difference": float(f1_metrics["net_return"] - f0_metrics["net_return"]),
                    "sharpe_difference": float(
                        f1_metrics["annualized_sharpe"] - f0_metrics["annualized_sharpe"]
                    ),
                    "edge_per_turnover_difference_bps": (
                        None
                        if f0_metrics["edge_per_turnover_bps"] is None
                        or f1_metrics["edge_per_turnover_bps"] is None
                        else float(
                            f1_metrics["edge_per_turnover_bps"]
                            - f0_metrics["edge_per_turnover_bps"]
                        )
                    ),
                },
                "capacity_diagnostics": {
                    "f0": capacity(f0_metrics),
                    "f1": capacity(f1_metrics),
                },
            }
            result["markets"][spot_id] = market_result
            deterministic_payloads[spot_id] = (
                events.reset_index().to_csv(index=False, lineterminator="\n").encode()
                + hourly.reindex(expected).reset_index().to_csv(index=False, lineterminator="\n").encode()
                + canonical_json(market_result)
            )

        result["bootstrap"] = bootstrap(paths, hourly_episodes)
        gates: list[bool] = []
        for spot_id, market_result in result["markets"].items():
            policies = market_result["policies"]
            f0_metrics = policies["f0_funding_only"]
            f1_metrics = policies["f1_strict_unwind"]
            residual = market_result["benchmark_residual"]["f1_minus_trend"]
            edge_delta = market_result["f1_minus_f0"]["edge_per_turnover_difference_bps"]
            gates.extend(
                [
                    f1_metrics["net_return"] > 0,
                    f1_metrics["annualized_sharpe"] > 0,
                    f1_metrics["edge_per_turnover_bps"] is not None
                    and f1_metrics["edge_per_turnover_bps"] > 0,
                    f1_metrics["annualized_sharpe"] > f0_metrics["annualized_sharpe"],
                    edge_delta is not None and edge_delta > 0,
                    residual["sharpe"] > 0,
                    f1_metrics["complete_168h_blocks"] > 0
                    and f1_metrics["profitable_168h_blocks"]
                    >= math.ceil(f1_metrics["complete_168h_blocks"] / 2),
                    f1_metrics["positive_block_concentration"] is not None
                    and f1_metrics["positive_block_concentration"] <= 0.5,
                ]
            )
        for endpoint in result["bootstrap"]["endpoints"].values():
            gates.append(
                endpoint.get("one_sided_95pct_lower_bound") is not None
                and endpoint["one_sided_95pct_lower_bound"] > 0
                and endpoint.get("holm_adjusted_p", 1.0) < 0.05
            )
        result["verdict"] = (
            "insufficient_history_positive_diagnostic"
            if all(gates)
            else "funding_basis_family_rejected_recent_window"
        )
        result["qualification_note"] = (
            "A positive diagnostic cannot promote the family because the frozen 8x90d design is unavailable."
        )
        result["deterministic_analysis_sha256"] = {
            market: sha256_bytes(payload) for market, payload in deterministic_payloads.items()
        }

    output = canonical_json(result)
    (args.output_dir / "result-summary.json").write_bytes(output)
    (args.output_dir / "result-summary.sha256").write_text(
        f"{sha256_bytes(output)}  result-summary.json\n", encoding="utf-8"
    )
    (args.output_dir / "source-manifest.json").write_bytes(canonical_json(source_manifests))
    print(json.dumps(result, indent=2, sort_keys=True, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
